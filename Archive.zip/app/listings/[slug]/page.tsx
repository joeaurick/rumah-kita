// app/listings/[slug]/page.tsx
export default function PropertyDetail() {
  return (
    <section className="px-6 py-10">
      <h2 className="text-2xl font-bold mb-4">Detail Properti</h2>
      <p>Informasi lengkap mengenai properti yang dipilih.</p>
    </section>
  )
}